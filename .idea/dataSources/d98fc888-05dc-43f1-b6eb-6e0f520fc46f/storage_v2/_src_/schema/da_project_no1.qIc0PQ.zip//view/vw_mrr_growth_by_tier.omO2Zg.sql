create definer = root@localhost view vw_mrr_growth_by_tier as
with recursive
    `months` as (select last_day('2023-01-01') AS `month_end`
                 union all
                 select last_day((`months`.`month_end` + interval 1 month)) AS `last_day(date_add(month_end, interval 1 month))`
                 from `months`
                 where (`months`.`month_end` <= '2024-11-30')),
    `plan_tier_list` as (select distinct `da_project_no1`.`subscriptions`.`plan_tier` AS `plan_tier`
                         from `da_project_no1`.`subscriptions`),
    `month_plan_tier_combo` as (select `m`.`month_end` AS `month_end`, `p`.`plan_tier` AS `plan_tier`
                                from (`months` `m` join `plan_tier_list` `p`)),
    `mrr_table` as (select `m_t_combo`.`month_end`                                         AS `month_end`,
                           `da_project_no1`.`subscriptions`.`plan_tier`                    AS `plan_tier`,
                           coalesce(sum(`da_project_no1`.`subscriptions`.`mrr_amount`), 0) AS `mrr_in_month`
                    from (`month_plan_tier_combo` `m_t_combo` left join `da_project_no1`.`subscriptions`
                          on (((`da_project_no1`.`subscriptions`.`start_date` <= `m_t_combo`.`month_end`) and
                               ((`da_project_no1`.`subscriptions`.`end_date` is null) or
                                (`da_project_no1`.`subscriptions`.`end_date` > `m_t_combo`.`month_end`)) and
                               (`da_project_no1`.`subscriptions`.`plan_tier` = `m_t_combo`.`plan_tier`))))
                    group by `m_t_combo`.`month_end`, `da_project_no1`.`subscriptions`.`plan_tier`),
    `mrr_total` as (select `months`.`month_end`                                            AS `month_end`,
                           'Total'                                                         AS `plan_tier`,
                           coalesce(sum(`da_project_no1`.`subscriptions`.`mrr_amount`), 0) AS `mrr_in_month`
                    from (`months` left join `da_project_no1`.`subscriptions`
                          on (((`da_project_no1`.`subscriptions`.`start_date` <= `months`.`month_end`) and
                               ((`da_project_no1`.`subscriptions`.`end_date` is null) or
                                (`da_project_no1`.`subscriptions`.`end_date` > `months`.`month_end`)))))
                    group by `months`.`month_end`)
select `mrr_table`.`month_end`                                                                      AS `month_end`,
       `mrr_table`.`plan_tier`                                                                      AS `plan_tier`,
       `mrr_table`.`mrr_in_month`                                                                   AS `mrr_in_month`,
       ifnull(lag(`mrr_table`.`mrr_in_month`)
                  OVER (PARTITION BY `mrr_table`.`plan_tier` ORDER BY `mrr_table`.`month_end` ),
              0)                                                                                    AS `prev_mrr_in_month`,
       (case
            when (lag(`mrr_table`.`mrr_in_month`)
                      OVER (PARTITION BY `mrr_table`.`plan_tier` ORDER BY `mrr_table`.`month_end` ) <> 0) then round(
                    (((`mrr_table`.`mrr_in_month` - lag(`mrr_table`.`mrr_in_month`)
                                                        OVER (PARTITION BY `mrr_table`.`plan_tier` ORDER BY `mrr_table`.`month_end` )) /
                      lag(`mrr_table`.`mrr_in_month`)
                          OVER (PARTITION BY `mrr_table`.`plan_tier` ORDER BY `mrr_table`.`month_end` )) * 1.0),
                    6) end)                                                                         AS `mrr_change_rate`
from `mrr_table`
union all
select `mrr_total`.`month_end`                                                                      AS `month_end`,
       `mrr_total`.`plan_tier`                                                                      AS `plan_tier`,
       `mrr_total`.`mrr_in_month`                                                                   AS `mrr_in_month`,
       ifnull(lag(`mrr_total`.`mrr_in_month`) OVER (ORDER BY `mrr_total`.`month_end` ),
              0)                                                                                    AS `prev_mrr_in_month`,
       round((((`mrr_total`.`mrr_in_month` - lag(`mrr_total`.`mrr_in_month`) OVER (ORDER BY `mrr_total`.`month_end` )) /
               lag(`mrr_total`.`mrr_in_month`) OVER (ORDER BY `mrr_total`.`month_end` )) * 1.0), 6) AS `mrr_change_rate`
from `mrr_total`
order by `plan_tier`, `month_end`;

