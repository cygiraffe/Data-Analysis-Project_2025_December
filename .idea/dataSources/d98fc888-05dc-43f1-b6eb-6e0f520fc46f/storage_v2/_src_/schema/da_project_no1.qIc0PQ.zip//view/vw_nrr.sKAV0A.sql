create definer = root@localhost view vw_nrr as
with recursive
    `months` as (select last_day('2024-01-01') AS `month_end`
                 union all
                 select last_day((`months`.`month_end` + interval 1 month)) AS `last_day(DATE_ADD(month_end, INTERVAL 1 MONTH))`
                 from `months`
                 where (`months`.`month_end` < cast('2024-12-01' as date))),
    `mrr_past` as (select `months`.`month_end`                               AS `month_end`,
                          `da_project_no1`.`subscriptions`.`account_id`      AS `account_id`,
                          sum(`da_project_no1`.`subscriptions`.`mrr_amount`) AS `cohort_mrr`
                   from (`months` join `da_project_no1`.`subscriptions`)
                   where ((`da_project_no1`.`subscriptions`.`start_date` <=
                           (`months`.`month_end` - interval 12 month)) and
                          ((`da_project_no1`.`subscriptions`.`end_date` is null) or
                           (`da_project_no1`.`subscriptions`.`end_date` >= (`months`.`month_end` - interval 12 month))))
                   group by `months`.`month_end`, `da_project_no1`.`subscriptions`.`account_id`
                   having (sum(`da_project_no1`.`subscriptions`.`mrr_amount`) > 0)),
    `mrr_current` as (select `months`.`month_end`                               AS `month_end`,
                             `da_project_no1`.`subscriptions`.`account_id`      AS `account_id`,
                             sum(`da_project_no1`.`subscriptions`.`mrr_amount`) AS `current_mrr`
                      from (`months` join `da_project_no1`.`subscriptions`)
                      where ((`da_project_no1`.`subscriptions`.`start_date` <= `months`.`month_end`) and
                             ((`da_project_no1`.`subscriptions`.`end_date` is null) or
                              (`da_project_no1`.`subscriptions`.`end_date` >= `months`.`month_end`)))
                      group by `months`.`month_end`, `da_project_no1`.`subscriptions`.`account_id`
                      having (sum(`da_project_no1`.`subscriptions`.`mrr_amount`) > 0))
select `mrr_past`.`month_end`                        AS `month_end`,
       sum(`mrr_past`.`cohort_mrr`)                  AS `cohort_mrr_final`,
       sum(coalesce(`mrr_current`.`current_mrr`, 0)) AS `current_mrr_final`,
       (case
            when (sum(coalesce(`mrr_past`.`cohort_mrr`, 0)) <> 0) then concat(
                    round(((sum(`mrr_current`.`current_mrr`) * 100) / sum(`mrr_past`.`cohort_mrr`)), 2), '%')
            else NULL end)                           AS `nrr_rate`
from (`mrr_past` left join `mrr_current` on (((`mrr_past`.`month_end` = `mrr_current`.`month_end`) and
                                              (`mrr_past`.`account_id` = `mrr_current`.`account_id`))))
group by `mrr_past`.`month_end`
order by `mrr_past`.`month_end`;

