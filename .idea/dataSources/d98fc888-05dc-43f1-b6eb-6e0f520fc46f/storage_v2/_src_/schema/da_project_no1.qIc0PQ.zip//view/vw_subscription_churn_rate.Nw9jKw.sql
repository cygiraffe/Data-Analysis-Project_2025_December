create definer = root@localhost view vw_subscription_churn_rate as
with recursive
    `months` as (select cast('2023-01-01' as date) AS `month_date`
                 union all
                 select (`months`.`month_date` + interval 1 month) AS `DATE_ADD(month_date, INTERVAL 1 MONTH)`
                 from `months`
                 where (`months`.`month_date` < '2024-12-01')),
    `monthly_metrics` as (select `m`.`month_date`                                            AS `month_date`,
                                 (select count(distinct `da_project_no1`.`subscriptions`.`subscription_id`)
                                  from `da_project_no1`.`subscriptions`
                                  where ((`da_project_no1`.`subscriptions`.`start_date` < `m`.`month_date`) and
                                         ((`da_project_no1`.`subscriptions`.`end_date` is null) or
                                          (`da_project_no1`.`subscriptions`.`end_date` >= `m`.`month_date`)) and
                                         (`da_project_no1`.`subscriptions`.`is_trial` = 0))) AS `subs_at_start`,
                                 (select count(distinct `da_project_no1`.`subscriptions`.`subscription_id`)
                                  from `da_project_no1`.`subscriptions`
                                  where ((`da_project_no1`.`subscriptions`.`start_date` < `m`.`month_date`) and
                                         (`da_project_no1`.`subscriptions`.`end_date` >= `m`.`month_date`) and
                                         (`da_project_no1`.`subscriptions`.`end_date` <
                                          (`m`.`month_date` + interval 1 month)) and
                                         (`da_project_no1`.`subscriptions`.`is_trial` = 0))) AS `churned_subs`
                          from `months` `m`)
select date_format(`monthly_metrics`.`month_date`, '%Y-%m')                                                AS `month`,
       `monthly_metrics`.`subs_at_start`                                                                   AS `subscriptions_at_month_start`,
       `monthly_metrics`.`churned_subs`                                                                    AS `churned_during_month`,
       round(((`monthly_metrics`.`churned_subs` * 1.0) / nullif(`monthly_metrics`.`subs_at_start`, 0)),
             6)                                                                                            AS `subscription_churn_rate`
from `monthly_metrics`
order by `monthly_metrics`.`month_date`;

