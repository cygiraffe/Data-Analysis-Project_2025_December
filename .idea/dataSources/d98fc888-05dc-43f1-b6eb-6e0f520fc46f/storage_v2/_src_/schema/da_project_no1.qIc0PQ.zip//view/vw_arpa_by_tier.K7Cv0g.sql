create definer = root@localhost view vw_arpa_by_tier as
with recursive
    `months` as (select last_day('2023-01-01') AS `month_end`
                 union all
                 select last_day((`months`.`month_end` + interval 1 month)) AS `last_day(date_add(month_end, interval 1 month))`
                 from `months`
                 where (`months`.`month_end` <= '2024-11-30')),
    `plan_tier_list` as (select distinct `da_project_no1`.`subscriptions`.`plan_tier` AS `plan_tier`
                         from `da_project_no1`.`subscriptions`),
    `month_plan_tier_combo` as (select `m`.`month_end` AS `month_end`, `p`.`plan_tier` AS `plan_tier`
                                from (`months` `m` join `plan_tier_list` `p`)),
    `mrr_table` as (select `m_t_combo`.`month_end`                                         AS `month_end`,
                           `da_project_no1`.`subscriptions`.`plan_tier`                    AS `plan_tier`,
                           coalesce(sum(`da_project_no1`.`subscriptions`.`mrr_amount`), 0) AS `mrr_in_month`,
                           count(distinct `da_project_no1`.`subscriptions`.`account_id`)   AS `number_of_accounts`
                    from (`month_plan_tier_combo` `m_t_combo` left join `da_project_no1`.`subscriptions`
                          on (((`da_project_no1`.`subscriptions`.`start_date` <= `m_t_combo`.`month_end`) and
                               ((`da_project_no1`.`subscriptions`.`end_date` is null) or
                                (`da_project_no1`.`subscriptions`.`end_date` > `m_t_combo`.`month_end`)) and
                               (`da_project_no1`.`subscriptions`.`plan_tier` = `m_t_combo`.`plan_tier`))))
                    group by `m_t_combo`.`month_end`, `da_project_no1`.`subscriptions`.`plan_tier`),
    `mrr_total` as (select `months`.`month_end`                                            AS `month_end`,
                           'Total'                                                         AS `plan_tier`,
                           coalesce(sum(`da_project_no1`.`subscriptions`.`mrr_amount`), 0) AS `mrr_in_month`,
                           count(distinct `da_project_no1`.`subscriptions`.`account_id`)   AS `number_of_accounts`
                    from (`months` left join `da_project_no1`.`subscriptions`
                          on (((`da_project_no1`.`subscriptions`.`start_date` <= `months`.`month_end`) and
                               ((`da_project_no1`.`subscriptions`.`end_date` is null) or
                                (`da_project_no1`.`subscriptions`.`end_date` > `months`.`month_end`)))))
                    group by `months`.`month_end`)
select `mrr_table`.`month_end`          AS `month_end`,
       `mrr_table`.`plan_tier`          AS `plan_tier`,
       `mrr_table`.`mrr_in_month`       AS `mrr_in_month`,
       `mrr_table`.`number_of_accounts` AS `number_of_accounts`,
       (case
            when (`mrr_table`.`number_of_accounts` > 0) then round(
                    (`mrr_table`.`mrr_in_month` / `mrr_table`.`number_of_accounts`), 2)
            else 0 end)                 AS `arpa`
from `mrr_table`
union all
select `mrr_total`.`month_end`          AS `month_end`,
       `mrr_total`.`plan_tier`          AS `plan_tier`,
       `mrr_total`.`mrr_in_month`       AS `mrr_in_month`,
       `mrr_total`.`number_of_accounts` AS `number_of_accounts`,
       (case
            when (`mrr_total`.`number_of_accounts` > 0) then round(
                    (`mrr_total`.`mrr_in_month` / `mrr_total`.`number_of_accounts`), 2)
            else 0 end)                 AS `arpa`
from `mrr_total`
order by `plan_tier`, `month_end`;

