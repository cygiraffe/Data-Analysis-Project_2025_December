create definer = root@localhost view vw_expansion_mrr_rate as
with recursive
    `months` as (select last_day('2023-01-01') AS `month`
                 union all
                 select last_day((`months`.`month` + interval 1 month)) AS `last_day(DATE_ADD(month, INTERVAL 1 MONTH))`
                 from `months`
                 where (`months`.`month` < cast('2024-12-01' as date))),
    `accounts_simple` as (select `da_project_no1`.`accounts`.`account_id`      AS `account_id`,
                                 `da_project_no1`.`accounts`.`country`         AS `country`,
                                 `da_project_no1`.`accounts`.`referral_source` AS `referral_source`
                          from `da_project_no1`.`accounts`),
    `months_accounts_combo` as (select `months`.`month`                    AS `month`,
                                       `accounts_simple`.`account_id`      AS `account_id`,
                                       `accounts_simple`.`country`         AS `country`,
                                       `accounts_simple`.`referral_source` AS `referral_source`
                                from (`months` join `accounts_simple`)),
    `account_monthly_mrr` as (select `m`.`month`                                 AS `month`,
                                     `m`.`account_id`                            AS `account_id`,
                                     `m`.`country`                               AS `country`,
                                     `m`.`referral_source`                       AS `referral_source`,
                                     coalesce((select sum(`s`.`mrr_amount`)
                                               from `da_project_no1`.`subscriptions` `s`
                                               where ((`s`.`account_id` = `m`.`account_id`) and
                                                      (`s`.`start_date` <= `m`.`month`) and
                                                      ((`s`.`end_date` is null) or (`s`.`end_date` > `m`.`month`)) and
                                                      (`s`.`is_trial` = 0))), 0) AS `this_month_mrr`
                              from `months_accounts_combo` `m`),
    `with_lag` as (select `account_monthly_mrr`.`month`                                                                      AS `month`,
                          `account_monthly_mrr`.`account_id`                                                                 AS `account_id`,
                          `account_monthly_mrr`.`country`                                                                    AS `country`,
                          `account_monthly_mrr`.`referral_source`                                                            AS `referral_source`,
                          `account_monthly_mrr`.`this_month_mrr`                                                             AS `this_month_mrr`,
                          lag(`account_monthly_mrr`.`this_month_mrr`)
                              OVER (PARTITION BY `account_monthly_mrr`.`account_id` ORDER BY `account_monthly_mrr`.`month` ) AS `last_month_mrr`
                   from `account_monthly_mrr`),
    `expansion_mrr_table` as (select `with_lag`.`month`                       AS `month`,
                                     `with_lag`.`account_id`                  AS `account_id`,
                                     `with_lag`.`country`                     AS `country`,
                                     `with_lag`.`referral_source`             AS `referral_source`,
                                     coalesce(`with_lag`.`last_month_mrr`, 0) AS `prev_month_mrr`,
                                     `with_lag`.`this_month_mrr`              AS `current_month_mrr`,
                                     (case
                                          when ((coalesce(`with_lag`.`last_month_mrr`, 0) > 0) and
                                                (`with_lag`.`this_month_mrr` >
                                                 coalesce(`with_lag`.`last_month_mrr`, 0))) then (
                                              `with_lag`.`this_month_mrr` - coalesce(`with_lag`.`last_month_mrr`, 0))
                                          else 0 end)                         AS `expansion_mrr`,
                                     (case
                                          when ((coalesce(`with_lag`.`last_month_mrr`, 0) > 0) and
                                                (`with_lag`.`this_month_mrr` > 0) and (`with_lag`.`this_month_mrr` <
                                                                                       coalesce(`with_lag`.`last_month_mrr`, 0)))
                                              then (coalesce(`with_lag`.`last_month_mrr`, 0) -
                                                    `with_lag`.`this_month_mrr`)
                                          else 0 end)                         AS `contraction_mrr`
                              from `with_lag`),
    `by_segment` as (select `expansion_mrr_table`.`month`                                      AS `month`,
                            `expansion_mrr_table`.`country`                                    AS `country`,
                            `expansion_mrr_table`.`referral_source`                            AS `referral_source`,
                            sum(`expansion_mrr_table`.`prev_month_mrr`)                        AS `starting_mrr`,
                            sum(`expansion_mrr_table`.`expansion_mrr`)                         AS `total_expansion_mrr`,
                            sum(`expansion_mrr_table`.`contraction_mrr`)                       AS `total_contraction_mrr`,
                            round(((sum(`expansion_mrr_table`.`expansion_mrr`) * 1.0) /
                                   nullif(sum(`expansion_mrr_table`.`prev_month_mrr`), 0)), 6) AS `expansion_rate`,
                            round(((sum(`expansion_mrr_table`.`contraction_mrr`) * 1.0) /
                                   nullif(sum(`expansion_mrr_table`.`prev_month_mrr`), 0)), 6) AS `contraction_rate`,
                            'segment'                                                          AS `agg_level`
                     from `expansion_mrr_table`
                     where ((`expansion_mrr_table`.`prev_month_mrr` > 0) or
                            (`expansion_mrr_table`.`current_month_mrr` > 0))
                     group by `expansion_mrr_table`.`month`, `expansion_mrr_table`.`country`,
                              `expansion_mrr_table`.`referral_source`),
    `segment_total` as (select `expansion_mrr_table`.`month`                                      AS `month`,
                               'total'                                                            AS `country`,
                               'total'                                                            AS `referral_source`,
                               sum(`expansion_mrr_table`.`prev_month_mrr`)                        AS `starting_mrr`,
                               sum(`expansion_mrr_table`.`expansion_mrr`)                         AS `total_expansion_mrr`,
                               sum(`expansion_mrr_table`.`contraction_mrr`)                       AS `total_contraction_mrr`,
                               round(((sum(`expansion_mrr_table`.`expansion_mrr`) * 1.0) /
                                      nullif(sum(`expansion_mrr_table`.`prev_month_mrr`), 0)), 6) AS `expansion_rate`,
                               round(((sum(`expansion_mrr_table`.`contraction_mrr`) * 1.0) /
                                      nullif(sum(`expansion_mrr_table`.`prev_month_mrr`), 0)), 6) AS `contraction_rate`,
                               'total'                                                            AS `agg_level`
                        from `expansion_mrr_table`
                        where ((`expansion_mrr_table`.`prev_month_mrr` > 0) or
                               (`expansion_mrr_table`.`current_month_mrr` > 0))
                        group by `expansion_mrr_table`.`month`),
    `by_country` as (select `expansion_mrr_table`.`month`                                      AS `month`,
                            `expansion_mrr_table`.`country`                                    AS `country`,
                            'all'                                                              AS `referral_source`,
                            sum(`expansion_mrr_table`.`prev_month_mrr`)                        AS `starting_mrr`,
                            sum(`expansion_mrr_table`.`expansion_mrr`)                         AS `total_expansion_mrr`,
                            sum(`expansion_mrr_table`.`contraction_mrr`)                       AS `total_contraction_mrr`,
                            round(((sum(`expansion_mrr_table`.`expansion_mrr`) * 1.0) /
                                   nullif(sum(`expansion_mrr_table`.`prev_month_mrr`), 0)), 6) AS `expansion_rate`,
                            round(((sum(`expansion_mrr_table`.`contraction_mrr`) * 1.0) /
                                   nullif(sum(`expansion_mrr_table`.`prev_month_mrr`), 0)), 6) AS `contraction_rate`,
                            'by_country'                                                       AS `agg_level`
                     from `expansion_mrr_table`
                     where ((`expansion_mrr_table`.`prev_month_mrr` > 0) or
                            (`expansion_mrr_table`.`current_month_mrr` > 0))
                     group by `expansion_mrr_table`.`month`, `expansion_mrr_table`.`country`)
select `by_segment`.`month`                 AS `month`,
       `by_segment`.`country`               AS `country`,
       `by_segment`.`referral_source`       AS `referral_source`,
       `by_segment`.`starting_mrr`          AS `starting_mrr`,
       `by_segment`.`total_expansion_mrr`   AS `total_expansion_mrr`,
       `by_segment`.`total_contraction_mrr` AS `total_contraction_mrr`,
       `by_segment`.`expansion_rate`        AS `expansion_rate`,
       `by_segment`.`contraction_rate`      AS `contraction_rate`,
       `by_segment`.`agg_level`             AS `agg_level`
from `by_segment`
union all
select `segment_total`.`month`                 AS `month`,
       `segment_total`.`country`               AS `country`,
       `segment_total`.`referral_source`       AS `referral_source`,
       `segment_total`.`starting_mrr`          AS `starting_mrr`,
       `segment_total`.`total_expansion_mrr`   AS `total_expansion_mrr`,
       `segment_total`.`total_contraction_mrr` AS `total_contraction_mrr`,
       `segment_total`.`expansion_rate`        AS `expansion_rate`,
       `segment_total`.`contraction_rate`      AS `contraction_rate`,
       `segment_total`.`agg_level`             AS `agg_level`
from `segment_total`
union all
select `by_country`.`month`                 AS `month`,
       `by_country`.`country`               AS `country`,
       `by_country`.`referral_source`       AS `referral_source`,
       `by_country`.`starting_mrr`          AS `starting_mrr`,
       `by_country`.`total_expansion_mrr`   AS `total_expansion_mrr`,
       `by_country`.`total_contraction_mrr` AS `total_contraction_mrr`,
       `by_country`.`expansion_rate`        AS `expansion_rate`,
       `by_country`.`contraction_rate`      AS `contraction_rate`,
       `by_country`.`agg_level`             AS `agg_level`
from `by_country`
order by `month`, `country`, `referral_source`;

