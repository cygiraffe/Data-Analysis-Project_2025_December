create definer = root@localhost view vw_mrr_growth_by_industry as
with recursive
    `months` as (select last_day('2023-01-01') AS `month_end`
                 union all
                 select last_day((`months`.`month_end` + interval 1 month)) AS `last_day(date_add(month_end, interval 1 month))`
                 from `months`
                 where (`months`.`month_end` <= '2024-11-30')),
    `mrr_total` as (select `months`.`month_end`                                            AS `month_end`,
                           'Total'                                                         AS `industry`,
                           coalesce(sum(`da_project_no1`.`subscriptions`.`mrr_amount`), 0) AS `mrr_in_month`
                    from (`months` left join `da_project_no1`.`subscriptions`
                          on (((`da_project_no1`.`subscriptions`.`start_date` <= `months`.`month_end`) and
                               ((`da_project_no1`.`subscriptions`.`end_date` is null) or
                                (`da_project_no1`.`subscriptions`.`end_date` > `months`.`month_end`)))))
                    group by `months`.`month_end`)
select `mrr_total`.`month_end`                                                                      AS `month_end`,
       `mrr_total`.`industry`                                                                       AS `industry`,
       `mrr_total`.`mrr_in_month`                                                                   AS `mrr_in_month`,
       ifnull(lag(`mrr_total`.`mrr_in_month`) OVER (ORDER BY `mrr_total`.`month_end` ),
              0)                                                                                    AS `prev_mrr_in_month`,
       round((((`mrr_total`.`mrr_in_month` - lag(`mrr_total`.`mrr_in_month`) OVER (ORDER BY `mrr_total`.`month_end` )) /
               lag(`mrr_total`.`mrr_in_month`) OVER (ORDER BY `mrr_total`.`month_end` )) * 1.0), 6) AS `mrr_change_rate`
from `mrr_total`
order by `mrr_total`.`industry`, `mrr_total`.`month_end`;

