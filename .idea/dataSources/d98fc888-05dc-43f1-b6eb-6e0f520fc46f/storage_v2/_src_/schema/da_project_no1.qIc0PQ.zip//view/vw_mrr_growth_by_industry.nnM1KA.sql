create definer = root@localhost view vw_mrr_growth_by_industry as
with recursive
    `months` as (select last_day('2023-01-01') AS `month_end`
                 union all
                 select last_day((`months`.`month_end` + interval 1 month)) AS `last_day(date_add(month_end, interval 1 month))`
                 from `months`
                 where (`months`.`month_end` <= '2024-11-30')),
    `industry_list` as (select distinct `da_project_no1`.`accounts`.`industry` AS `industry`
                        from `da_project_no1`.`accounts`),
    `month_industry_combo` as (select `m`.`month_end` AS `month_end`, `i`.`industry` AS `industry`
                               from (`months` `m` join `industry_list` `i`)),
    `subscriptions_in_detail` as (select `da_project_no1`.`subscriptions`.`subscription_id`   AS `subscription_id`,
                                         `da_project_no1`.`subscriptions`.`account_id`        AS `account_id`,
                                         `da_project_no1`.`subscriptions`.`start_date`        AS `start_date`,
                                         `da_project_no1`.`subscriptions`.`end_date`          AS `end_date`,
                                         `da_project_no1`.`subscriptions`.`plan_tier`         AS `plan_tier`,
                                         `da_project_no1`.`subscriptions`.`seats`             AS `seats`,
                                         `da_project_no1`.`subscriptions`.`mrr_amount`        AS `mrr_amount`,
                                         `da_project_no1`.`subscriptions`.`arr_amount`        AS `arr_amount`,
                                         `da_project_no1`.`subscriptions`.`is_trial`          AS `is_trial`,
                                         `da_project_no1`.`subscriptions`.`upgraded`          AS `upgraded`,
                                         `da_project_no1`.`subscriptions`.`downgraded`        AS `downgraded`,
                                         `da_project_no1`.`subscriptions`.`churned`           AS `churned`,
                                         `da_project_no1`.`subscriptions`.`billing_frequency` AS `billing_frequency`,
                                         `da_project_no1`.`subscriptions`.`auto_renewed`      AS `auto_renewed`,
                                         `da_project_no1`.`accounts`.`industry`               AS `industry`
                                  from (`da_project_no1`.`subscriptions` left join `da_project_no1`.`accounts`
                                        on ((`da_project_no1`.`subscriptions`.`account_id` =
                                             `da_project_no1`.`accounts`.`account_id`)))),
    `mrr_table` as (select `m_i_combo`.`month_end`                                  AS `month_end`,
                           `m_i_combo`.`industry`                                   AS `industry`,
                           coalesce(sum(`subscriptions_in_detail`.`mrr_amount`), 0) AS `mrr_in_month`
                    from (`month_industry_combo` `m_i_combo` left join `subscriptions_in_detail`
                          on (((`subscriptions_in_detail`.`start_date` <= `m_i_combo`.`month_end`) and
                               ((`subscriptions_in_detail`.`end_date` is null) or
                                (`subscriptions_in_detail`.`end_date` > `m_i_combo`.`month_end`)) and
                               (`subscriptions_in_detail`.`industry` = `m_i_combo`.`industry`))))
                    group by `m_i_combo`.`month_end`, `m_i_combo`.`industry`),
    `mrr_total` as (select `months`.`month_end`                                            AS `month_end`,
                           'Total'                                                         AS `industry`,
                           coalesce(sum(`da_project_no1`.`subscriptions`.`mrr_amount`), 0) AS `mrr_in_month`
                    from (`months` left join `da_project_no1`.`subscriptions`
                          on (((`da_project_no1`.`subscriptions`.`start_date` <= `months`.`month_end`) and
                               ((`da_project_no1`.`subscriptions`.`end_date` is null) or
                                (`da_project_no1`.`subscriptions`.`end_date` > `months`.`month_end`)))))
                    group by `months`.`month_end`)
select `mrr_table`.`month_end`                                                                     AS `month_end`,
       `mrr_table`.`industry`                                                                      AS `industry`,
       `mrr_table`.`mrr_in_month`                                                                  AS `mrr_in_month`,
       ifnull(lag(`mrr_table`.`mrr_in_month`)
                  OVER (PARTITION BY `mrr_table`.`industry` ORDER BY `mrr_table`.`month_end` ),
              0)                                                                                   AS `prev_mrr_in_month`,
       (case
            when (lag(`mrr_table`.`mrr_in_month`)
                      OVER (PARTITION BY `mrr_table`.`industry` ORDER BY `mrr_table`.`month_end` ) <> 0) then round(
                    (((`mrr_table`.`mrr_in_month` - lag(`mrr_table`.`mrr_in_month`)
                                                        OVER (PARTITION BY `mrr_table`.`industry` ORDER BY `mrr_table`.`month_end` )) /
                      lag(`mrr_table`.`mrr_in_month`)
                          OVER (PARTITION BY `mrr_table`.`industry` ORDER BY `mrr_table`.`month_end` )) * 1.0),
                    6) end)                                                                        AS `mrr_change_rate`
from `mrr_table`
union all
select `mrr_total`.`month_end`                                                                      AS `month_end`,
       `mrr_total`.`industry`                                                                       AS `industry`,
       `mrr_total`.`mrr_in_month`                                                                   AS `mrr_in_month`,
       ifnull(lag(`mrr_total`.`mrr_in_month`) OVER (ORDER BY `mrr_total`.`month_end` ),
              0)                                                                                    AS `prev_mrr_in_month`,
       round((((`mrr_total`.`mrr_in_month` - lag(`mrr_total`.`mrr_in_month`) OVER (ORDER BY `mrr_total`.`month_end` )) /
               lag(`mrr_total`.`mrr_in_month`) OVER (ORDER BY `mrr_total`.`month_end` )) * 1.0), 6) AS `mrr_change_rate`
from `mrr_total`
order by `industry`, `month_end`;

